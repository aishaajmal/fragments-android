package com.example.my3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

public class firstFragment extends Fragment {

    int imgResId;

    public firstFragment(int resId)
    {

        this.imgResId = resId;
    }

    public firstFragment() { }

    @Override
    public View onCreateView(LayoutInflater in, ViewGroup container,
                             Bundle savedInstanceState)
    {
        View v = in.inflate(R.layout.fragment_first, container, false);
        ImageView i = v.findViewById(R.id.fullscreen_image);
        i.setImageResource(imgResId);
        return v;
    }
}
