package com.example.my3;

import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    int[] imgRes = { R.drawable.image1, R.drawable.image2, R.drawable.image3, R.drawable.image4 };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ImageView[] views = {
                findViewById(R.id.img1),
                findViewById(R.id.img2),
                findViewById(R.id.img3),
                findViewById(R.id.img4)
        };

        for (int i = 0; i < views.length; i++)
        {
            int index = i;
            views[i].setOnClickListener(v -> loadFragment(imgRes[index]));
        }


        loadFragment(imgRes[0]);
    }

    private void loadFragment(int resId)
    {
        firstFragment f = new firstFragment(resId);
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.fragment_container, f);
        ft.commit();
    }
}
